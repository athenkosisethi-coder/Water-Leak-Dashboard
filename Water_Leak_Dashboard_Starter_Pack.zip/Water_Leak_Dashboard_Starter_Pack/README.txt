POWER BI WATER LEAK DASHBOARD STARTER PACK

Files:
- PowerBI_Cleaned_Leak_Register.xlsx: cleaned, standardized leak register plus preserved raw cumulative worksheet.
- DAX_Measures.txt: DAX measures to create in Power BI Desktop.
- Power_Query_M_Code.txt: optional Power Query M import/type script. Replace the sample file path first.
- PowerBI_Implementation_Guide.docx: report page plan, setup instructions, data notes and limitations.
- Data_Profile.json: quick profile of the cleaned data.

Important:
This is an implementation starter pack, not a compiled Power BI .pbix report. Power BI Desktop is needed to create visuals, validate them and save the native .pbix file. The cumulative values sheet is preserved as raw because its 1,303-column layout needs reshaping before reliable modeling.
